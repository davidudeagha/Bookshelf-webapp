<?php
	//echo "FAULT";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>User Search</title>
</head>
<body>
	<table>
		<tr>
			<th>First Name</th>
			<th>Surname</th>
			<th>Username</th>
			<th>City</th>
		</tr>
		<?php
			foreach ($userSearchArray as $key => $value){
				//echo"<pre>";
				//print_r($value);
				//echo"</pre>";
				//<td>",$value->title,"</td>
				
				echo "<tr>
					<td>",$value["firstname"],"</td>
					<td>",$value["surname"],"</td>
					<td>",$value["username"],"</td>
					<td>",$value["city"],"</td>
				</tr>";
			}
		?>
	</table>
</body>
</html>