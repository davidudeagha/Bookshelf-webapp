<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

  <title>Shelf</title>

  <!-- Font Awesome Icons -->
  <link href="http://localhost/bookshelf_ci/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Google Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700">
  <link rel='stylesheet' type='text/css' href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic'>

  <!-- Plugin CSS -->
  <link rel="stylesheet" href="http://localhost/bookshelf_ci/vendor/magnific-popup/magnific-popup.css">
  <link rel="stylesheet" type="text/css" href="http://localhost/bookshelf_ci/main.css">

  <!-- Theme CSS - Includes Bootstrap -->
  <link rel="stylesheet" href=" http://localhost/bookshelf_ci/css/creative.css">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">Book Information</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto my-2 my-lg-0">
		<li class="nav-item">
            <a class="nav-link js-scroll-trigger" href='<?php echo base_url()."dashboard_controller/enter_dashboard"?>'>Welcome</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href='<?php echo base_url()."shelf_controller/add_book"?>'>New Book</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href='<?php echo base_url()."shelf_controller/display_books"?>'>Shelf</a>
          </li>
		   <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href='<?php echo base_url()."connect_controller/connect_options"?>'>Connect</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#login">Wishlist</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#register">Book Requests</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="<?php echo base_url()."login_controller/logout"?>">Logout</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>
  
  
  <!-- Shelf Display Section -->
  <header class="welcome" id="welcome">
  <div class="col-lg-8 align-self-baseline">
    <?php
			if(count($bookInfoArray) > 0){
					foreach ($bookInfoArray as $key => $value){
						
						echo "<br><br><br><div class='col-lg-20 align-self-end'><h2 class='text-uppercase text-white font-weight-bold'>Title: ",$value->title,"</h2><br>
						<div class='col-lg-10 align-self-end'><h2 class='text-uppercase text-white font-weight-bold'>Genre: ",$value->genre,"</h2><br></div>
						<div class='col-lg-20 align-self-end'><h2 class='text-uppercase text-white font-weight-bold'>Author: ",$value->author,"</h2><br></div>
						<div class='col-lg-10 align-self-end'><h2 class='text-uppercase text-white font-weight-bold'>Owner: ",$value->username,"</h2><br></div></div>";
						if($key == "userID"){
						echo "<div class='row h-100 align-items-center justify-content-center text-center'>
						<a class='btn btn-primary btn-xl js-scroll-trigger' href='",base_url().'review_controller/read_reviews/'.$value->bookID,"'>Read Reviews</a><br><br></br>
						</div>";
						echo "<div class='row h-100 align-items-center justify-content-center text-center'>
						<a class='btn btn-secondary btn-xl js-scroll-trigger' href='",base_url().'review_controller/write_review/'.$value->bookID,"'>Write A Review</a><br></br>
						</div>";
					}
				}
			}else{
				echo "<br><br><br><br><br><br><br>";
			}
			
			
		?>
	</div><br></br>
	
	</header>
	<div class="overlay"></div>

  <!--</header>-->
  
  



</body>
</html>