<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	
	<!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" href="https://getbootstrap.com/docs/4.4/examples/sign-in/signin.css">
	
	
    <title>Hello, world!</title>
  </head>
  <body>
	
    <form method="post" action="<?php echo base_url(); ?>login_controller/validate_login" class="form-signin">
		
		<div class="form-group">
			<img class="mb-4" src="/docs/4.4/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
			<h1 class="h3 mb-3 font-weight-normal">Bookshelf Sign in</h1>
			<label for="username" class="sr-only">Username</label><br>
			<input name="username" type="text" id="username" class="form-control" placeholder="Username" required autofocus>
			<span class="text-danger"><?php echo form_error("username")?></span>
		</div>
		
		<div class="form-group">
			<label for="password" class="sr-only">Password</label><br></br>
			<input name="password" type="password" id="password" class="form-control" placeholder="Password" required>
			<span class="text-danger"><?php echo form_error("password")?></span>
		</div>
		<div class="checkbox mb-3">
			<label>
				<input type="checkbox" value="remember-me"> Remember me
			</label>
		</div>
		
		<div class="form-group">
			<input type="submit" name="insert" value="Login" button class="btn btn-lg btn-primary btn-block"></button>
			<?php
				echo $this->session->flashdata("error");
			?>
		</div>
		<p class="mt-5 mb-3 text-muted">&copy; 2019-2020</p>
		
	</form>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>