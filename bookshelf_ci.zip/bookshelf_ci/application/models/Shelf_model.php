<?php
	class Shelf_model extends CI_Model{
		function shelf_check($username){
			//$this->load->database();
			//$this->db->select("title");
			//$this->db->where($data);
			//$loginquery = $this->db->get_where("users", $data);
			$shelfquery = $this->db->get_where("book", array("username" => "$username"));
			//$loginquery = $this->db->get("users");
			return $shelfquery->result();
			
			/*if($shelfquery->num_rows() > 0){
				return true;
			}
			else{
				return false;
			}*/
			//print_r($loginquery->result_array());
		}
		
		function book_check($bookID){
			$bookquery = $this->db->get_where("book", array("bookID" => "$bookID"));
			return $bookquery->result();
		}
		
		function can_insert_book($data, $title, $username){
			$this->db->insert("book", $data);
			$insertquery = $this->db->get_where("book", array("title" => "$title", "username" => "$username"));
			
			//return $insertquery->result();
			
			if($insertquery->num_rows() > 0){
				return true;
			}
			else{
				return false;
			}
		}
	}

?>