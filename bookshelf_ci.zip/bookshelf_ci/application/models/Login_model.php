<?php
	class Login_model extends CI_Model{
		function can_login($username, $password){
			//$this->load->database();
			//$this->db->select("username, password");
			//$this->db->where($data);
			//$loginquery = $this->db->get_where("users", $data);
			$loginquery = $this->db->get_where("users", array("username" => "$username", "password" => "$password"));
			//$loginquery = $this->db->get("users");
			$loginquery->result_array();
			if($loginquery->num_rows() > 0){
				return true;
			}
			else{
				return false;
			}
			print_r($loginquery->result_array());
		}
		
	}

?>