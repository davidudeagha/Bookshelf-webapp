<?php
	class User_model extends CI_Model{
		function create_user($data){
			$this->load->database();
			$this->db->insert("users", $data);
		}
		
		function login_user($data){
			$loginquery = NULL;
			$this->load->database();
			//$this->db->select("username, password");
			//$this->db->where($data);
			$loginquery = $this->db->get_where("users", $data);
			//$loginquery = $this->db->get_where("users", array("username" => "$username", "password" => "$password"));
			//$loginquery = $this->db->get("users");
			$loginquery->result_array();
			print_r($loginquery->result_array());
			
			/**if(empty($loginquery->result_array())){
				return false;
			}
			
			else{
				return true;
			}*/
			
		}
		
		function return_user_books($username){
			//$this->db->select("userID");
			//$userIDquery = $this->db->get("users");
			//$booksquery = $this->db->get_where("book", array("userID" => "$userID"));
		}
	}

?>