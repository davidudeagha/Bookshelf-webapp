<?php
	class Connect_model extends CI_Model{
		function user_check($name){
			//$this->load->database();
			//$this->db->select("title");
			//$this->db->where($data);
			//$loginquery = $this->db->get_where("users", $data);
			
			//$firstnamequery = $this->db->get_where("users", array("firstname" => "$name"));
			//$surnamequery = $this->db->get_where("users", array("surname" => "$name"));
			$this->db->like('firstname', $name); $this->db->or_like('surname', $name);
			
			$query = $this->db->get("users");
			//return array_merge($firstnamequery->result_array(), $surnamequery->result_array());
			return($query->result_array());
			
			/*if($shelfquery->num_rows() > 0){
				return true;
			}
			else{
				return false;
			}*/
			//print_r($loginquery->result_array());
		}
		
		function book_title_check($book){
			$this->db->like('title', $book);
			$bookquery = $this->db->get("book");

			return($bookquery->result_array());
		}
		
		function city_check($city){
			$this->db->like('city', $city);
			$cityquery = $this->db->get("users");

			return($cityquery->result_array());
		}
	}

?>