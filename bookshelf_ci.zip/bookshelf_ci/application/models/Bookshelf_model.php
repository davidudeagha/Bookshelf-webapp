<?php
	class Bookshelf_model extends CI_Model{

	}

?>