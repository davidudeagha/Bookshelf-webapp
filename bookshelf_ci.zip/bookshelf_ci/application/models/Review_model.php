<?php
	class Review_model extends CI_Model{
		function review_check($bookID){
			$reviewquery = $this->db->get_where("book_reviews", array("bookID" => "$bookID"));
			return $reviewquery->result();
		}
		
		function can_insert_review($reviewData, $title){
			$reviewquery1 = $this->db->get_where("book_reviews", array("title" => "$title"));
			$this->db->insert("book_reviews", $reviewData);
			$reviewquery2 = $this->db->get_where("book_reviews", array("title" => "$title", "username" => "$username"));
			
			//return $insertquery->result();
			
			if($reviewquery1->num_rows() == $reviewquery2->num_rows()){
				return false;
			}
			else{
				return true;
			}
		}
	}

?>