<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Dashboard_controller extends CI_Controller{
		public function enter_dashboard(){
            $this->load->helper("form");
			$this->load->helper("url");
			//$this->load->view("login_view");
			if($this->session->userdata("username") != ""){
				//echo "<h2>Welcome - ".$this->session->userdata("username")."</h2>";
				$this->load->view("dashboard_view");
				//return $this->session->userdata("username");
			}
			
			else{
				redirect(base_url()."login_controller/index");
			}
			
		}
	}