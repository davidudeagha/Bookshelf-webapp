<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Shelf_controller extends CI_Controller{
		public function display_books(){
            $this->load->helper("form");
			$this->load->helper("url");
			
			$this->load->model("Shelf_model");
			$shelfOwner = $this->session->userdata('username');
			$shelfData['bookArray'] = $this->Shelf_model->shelf_check($shelfOwner);
			
			$this->load->view("shelf_view", $shelfData);
		}
		
		public function display_search_user_books(){
            $this->load->helper("form");
			$this->load->helper("url");
			
			$this->load->model("Shelf_model");
			$shelfOwner = $this->uri->segment(3);
			$shelfData['bookArray'] = $this->Shelf_model->shelf_check($shelfOwner);
			
			$this->load->view("shelf_public_view", $shelfData);
		}
		
		public function add_book(){
			$this->load->helper("form");
			$this->load->helper("url");
			$this->load->view("shelf_addbook_view");
		}
		
		public function insert_book(){
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->load->helper("url");
			$this->form_validation->set_rules("title", "Title", "required");
			$this->form_validation->set_rules("genre", "Genre", "required|alpha");
			$this->form_validation->set_rules("author", "author", "required");
			
			
			if ($this->form_validation->run()){
				$title = $this->input->post("title");
				$username = $this->session->userdata("username");
				
				$data = array(
					"title" => $this->input->post("title"),
					"genre" => $this->input->post("genre"),
					"author" => $this->input->post("author"),
					"username" => $this->session->userdata("username")
				);
				
				$this->load->model("Shelf_model");
				if($this->Shelf_model->can_insert_book($data, $title, $username)){
					//this->display_books();
					redirect(base_url()."shelf_controller/display_books");
				}
				else{
					//$this->load->view('formsuccess');
					//$this->add_book();
					//$this->session->flashdata("error", "Invalid Username and Password");
					redirect(base_url()."shelf_controller/add_book");
				}
				
            }
            else{
				//$this->load->view('formsuccess');
				$this->index();
				//$this->session->flashdata("error", "Invalid Username and Password");
				//redirect(base_url()."login_controller/index");
            }
		}
		
		public function book_info($bookID){
			$this->load->helper("url");
			//$title = $this->uri->segment(3);   
			$this->load->model("Shelf_model");
			$bookData['bookInfoArray'] = $this->Shelf_model->book_check($bookID);
			$this->session->set_userdata('bookID', $bookID);
			$this->load->view("bookinfo_view", $bookData);
		}
		
		public function public_book_info($bookID){
			$this->load->helper("url");
			//$title = $this->uri->segment(3);   
			$this->load->model("Shelf_model");
			$publicBookData['pubBookInfoArray'] = $this->Shelf_model->book_check($bookID);
			$this->session->set_userdata('bookID', $bookID);
			$this->load->view("bookinfo_public_view", $publicBookData);
		}
	}

?>