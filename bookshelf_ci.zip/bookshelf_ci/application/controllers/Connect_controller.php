<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Connect_controller extends CI_Controller{
		public function connect_options(){
            $this->load->helper("form");
			$this->load->helper("url");
			$this->load->view("connect_options_view");
		}
		
		public function search_for_user(){
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->load->helper("url");
			$this->form_validation->set_rules("name", "Name", "required");
			
			
			if ($this->form_validation->run()){
				$name = $this->input->post("name");
				
				/*$data = array(
					"title" => $this->input->post("title"),
					"genre" => $this->input->post("genre"),
					"author" => $this->input->post("author"),
					"username" => $this->session->userdata("username")
				);*/
				
				$this->load->model("Connect_model");
				$userData['userSearchArray'] = $this->Connect_model->user_check($name);
				$this->load->view("connect_by_user_view", $userData);
			}	else{
					//$this->load->view('formsuccess');
					//$this->add_book();
					//$this->session->flashdata("error", "Invalid Username and Password");
					//redirect(base_url()."connect_controller/connect_no_results");
					redirect(base_url()."connect_controller/connect_options");
				}
				
		}
		
		public function search_for_book(){
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->load->helper("url");
			$this->form_validation->set_rules("book", "Book", "required");
			
			
			if ($this->form_validation->run()){
				$book = $this->input->post("book");
				
				$this->load->model("Connect_model");
				$bookData['bookSearchArray'] = $this->Connect_model->book_title_check($book);
				$this->load->view("connect_by_book_view", $bookData);
			}	else{
					
					redirect(base_url()."connect_controller/connect_options");
				}
		}
		
		public function search_for_city(){
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->load->helper("url");
			$this->form_validation->set_rules("city", "City", "required");
			
			
			if ($this->form_validation->run()){
				$city = $this->input->post("city");
				
				$this->load->model("Connect_model");
				$userData['userSearchArray'] = $this->Connect_model->city_check($city);
				$this->load->view("connect_by_user_view", $userData);
			}	else{
					redirect(base_url()."connect_controller/connect_options");
				}
		}
	}

?>