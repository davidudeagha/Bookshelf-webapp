<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Home_controller extends CI_Controller{
		public function index(){
			$this->load->helper("form");
			$this->load->helper("url");
			$this->load->view("home_view");
			//$this->load->view("myindexview");
			//$this->load->view("login_view");
		}
		
	}

?>