<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Review_controller extends CI_Controller{

		public function read_reviews($bookID){
            $this->load->helper("form");
			$this->load->helper("url");
			
			$bookID = $this->uri->segment(3);   
			$this->load->model("Review_model");
			$reviewData['reviewArray'] = $this->Review_model->review_check($bookID);
			
			$this->load->view("review_read_view", $reviewData);
			//$this->load->model("Review_model");
			//$this->load->view("review_read_view");
		}
		
		public function write_review($bookID){
			$this->load->helper("form");
			$this->load->helper("url");
			
			$bookID = $this->uri->segment(3);
			$this->load->view("review_write_view", $bookID);
			
		}
		
		public function insert_review(){
			$this->load->helper("form");
			$this->load->helper("url");

			$this->load->library('form_validation');
			$this->form_validation->set_rules("title", "Title", "required");
			$this->form_validation->set_rules("review_content", "Review_content", "required");
			//$this->form_validation->set_rules("date_written", "Date of birth", 'regex_match[(0[1-9]|1[0-9]|2[0-9]|3(0|1))-(0[1-9]|1[0-2])-\d{4}]');
			
			
			if ($this->form_validation->run()){
				$title = $this->input->post("title");
				$reviewData = array(
					"username" => $this->session->userdata("username"),
					"title" => $this->input->post("title"),
					"date_written" => $this->input->post("date_written"),
					"review_content" => $this->input->post("review_content"),
					"bookID" => $this->session->userdata('bookID')
				);
				$this->load->model("Review_model");
				if($this->Review_model->can_insert_review($reviewData, $title)){
	
					redirect(base_url()."dashboard_controller/enter_dashboard");
				}
				else{
				//$this->load->view('formsuccess');
				//$this->index();
					//$this->session->flashdata("error", "Invalid Username and Password");
					redirect(base_url()."dashboard_controller/enter_dashboard");
				}
				
            }
            else{
				//$this->load->view('formsuccess');
				redirect(base_url()."shelf_controller/display_books");
				//$this->session->flashdata("error", "Invalid Username and Password");
				//redirect(base_url()."login_controller/index");
            }
			
		}
		
	}

?>