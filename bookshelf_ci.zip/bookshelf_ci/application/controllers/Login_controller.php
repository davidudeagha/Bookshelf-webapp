<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Login_controller extends CI_Controller{
		public function index(){
            $this->load->helper("form");
			$this->load->helper("url");
			$this->load->view("login_view");
			
		}
		
		public function validate_login(){
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->load->helper("url");
			$this->form_validation->set_rules("username", "Username", "required");
			$this->form_validation->set_rules("password", "Password", "required|alpha_numeric|max_length[12]");
			
			
			if ($this->form_validation->run()){
				$username = $this->input->post("username");
				$password = $this->input->post("password");
				$this->load->model("Login_model");
				if($this->Login_model->can_login($username, $password)){
					//$session_data = array(
						//"username" => $username
					//);
					//$this->session->set_userdata($session_data);
					$this->session->set_userdata('username', $username);
					//redirect(base_url()."home_controller/index");
					redirect(base_url()."dashboard_controller/enter_dashboard");
				}
				else{
				//$this->load->view('formsuccess');
				//$this->index();
				$this->session->flashdata("error", "Invalid Username and Password");
				redirect(base_url()."login_controller/index");
				}
				
            }
            else{
				//$this->load->view('formsuccess');
				$this->index();
				//$this->session->flashdata("error", "Invalid Username and Password");
				//redirect(base_url()."login_controller/index");
            }
		}
		
		public function logout(){
			$this->load->helper("url");
			$this->session->unset_userdata("username");
			$this->session->unset_userdata('bookID');
			redirect(base_url(). 'home_controller/index');
		}
		
	}

?>